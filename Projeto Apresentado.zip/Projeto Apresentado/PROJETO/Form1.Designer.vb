﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.txtEditor = New System.Windows.Forms.TextBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ArquivoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NovoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AbrirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalvarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.SairToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecoortarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopiarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ColarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeletarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.PosiçãaoDaLegendaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CentroMeioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CentroInferiorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CentroSuperiorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DireitaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DireitaInferiorToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DireitaSuperiorToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EsquerdaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EsquerdaInferiorToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EsquerdaSuperiorToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.SelecionarTudoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HoraDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormatarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FonteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PlanoDeFundoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SelecionarIdiomaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SobreToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtEditor
        '
        resources.ApplyResources(Me.txtEditor, "txtEditor")
        Me.txtEditor.Name = "txtEditor"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ArquivoToolStripMenuItem, Me.EditarToolStripMenuItem, Me.FormatarToolStripMenuItem, Me.ToolStripMenuItem1, Me.SobreToolStripMenuItem})
        resources.ApplyResources(Me.MenuStrip1, "MenuStrip1")
        Me.MenuStrip1.Name = "MenuStrip1"
        '
        'ArquivoToolStripMenuItem
        '
        Me.ArquivoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NovoToolStripMenuItem, Me.AbrirToolStripMenuItem, Me.SalvarToolStripMenuItem, Me.ToolStripSeparator1, Me.SairToolStripMenuItem})
        Me.ArquivoToolStripMenuItem.Name = "ArquivoToolStripMenuItem"
        resources.ApplyResources(Me.ArquivoToolStripMenuItem, "ArquivoToolStripMenuItem")
        '
        'NovoToolStripMenuItem
        '
        Me.NovoToolStripMenuItem.Name = "NovoToolStripMenuItem"
        resources.ApplyResources(Me.NovoToolStripMenuItem, "NovoToolStripMenuItem")
        '
        'AbrirToolStripMenuItem
        '
        Me.AbrirToolStripMenuItem.Name = "AbrirToolStripMenuItem"
        resources.ApplyResources(Me.AbrirToolStripMenuItem, "AbrirToolStripMenuItem")
        '
        'SalvarToolStripMenuItem
        '
        Me.SalvarToolStripMenuItem.Name = "SalvarToolStripMenuItem"
        resources.ApplyResources(Me.SalvarToolStripMenuItem, "SalvarToolStripMenuItem")
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        resources.ApplyResources(Me.ToolStripSeparator1, "ToolStripSeparator1")
        '
        'SairToolStripMenuItem
        '
        Me.SairToolStripMenuItem.Name = "SairToolStripMenuItem"
        resources.ApplyResources(Me.SairToolStripMenuItem, "SairToolStripMenuItem")
        '
        'EditarToolStripMenuItem
        '
        Me.EditarToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RecoortarToolStripMenuItem, Me.CopiarToolStripMenuItem, Me.ColarToolStripMenuItem, Me.DeletarToolStripMenuItem, Me.ToolStripSeparator3, Me.PosiçãaoDaLegendaToolStripMenuItem, Me.ToolStripSeparator2, Me.SelecionarTudoToolStripMenuItem, Me.HoraDataToolStripMenuItem})
        Me.EditarToolStripMenuItem.Name = "EditarToolStripMenuItem"
        resources.ApplyResources(Me.EditarToolStripMenuItem, "EditarToolStripMenuItem")
        '
        'RecoortarToolStripMenuItem
        '
        Me.RecoortarToolStripMenuItem.Name = "RecoortarToolStripMenuItem"
        resources.ApplyResources(Me.RecoortarToolStripMenuItem, "RecoortarToolStripMenuItem")
        '
        'CopiarToolStripMenuItem
        '
        Me.CopiarToolStripMenuItem.Name = "CopiarToolStripMenuItem"
        resources.ApplyResources(Me.CopiarToolStripMenuItem, "CopiarToolStripMenuItem")
        '
        'ColarToolStripMenuItem
        '
        Me.ColarToolStripMenuItem.Name = "ColarToolStripMenuItem"
        resources.ApplyResources(Me.ColarToolStripMenuItem, "ColarToolStripMenuItem")
        '
        'DeletarToolStripMenuItem
        '
        Me.DeletarToolStripMenuItem.Name = "DeletarToolStripMenuItem"
        resources.ApplyResources(Me.DeletarToolStripMenuItem, "DeletarToolStripMenuItem")
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        resources.ApplyResources(Me.ToolStripSeparator3, "ToolStripSeparator3")
        '
        'PosiçãaoDaLegendaToolStripMenuItem
        '
        Me.PosiçãaoDaLegendaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CentroMeioToolStripMenuItem, Me.DireitaToolStripMenuItem, Me.EsquerdaToolStripMenuItem})
        Me.PosiçãaoDaLegendaToolStripMenuItem.Name = "PosiçãaoDaLegendaToolStripMenuItem"
        resources.ApplyResources(Me.PosiçãaoDaLegendaToolStripMenuItem, "PosiçãaoDaLegendaToolStripMenuItem")
        '
        'CentroMeioToolStripMenuItem
        '
        Me.CentroMeioToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CentroInferiorToolStripMenuItem, Me.CentroSuperiorToolStripMenuItem})
        Me.CentroMeioToolStripMenuItem.Name = "CentroMeioToolStripMenuItem"
        resources.ApplyResources(Me.CentroMeioToolStripMenuItem, "CentroMeioToolStripMenuItem")
        '
        'CentroInferiorToolStripMenuItem
        '
        Me.CentroInferiorToolStripMenuItem.Name = "CentroInferiorToolStripMenuItem"
        resources.ApplyResources(Me.CentroInferiorToolStripMenuItem, "CentroInferiorToolStripMenuItem")
        '
        'CentroSuperiorToolStripMenuItem
        '
        Me.CentroSuperiorToolStripMenuItem.Name = "CentroSuperiorToolStripMenuItem"
        resources.ApplyResources(Me.CentroSuperiorToolStripMenuItem, "CentroSuperiorToolStripMenuItem")
        '
        'DireitaToolStripMenuItem
        '
        Me.DireitaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DireitaInferiorToolStripMenuItem1, Me.DireitaSuperiorToolStripMenuItem1})
        Me.DireitaToolStripMenuItem.Name = "DireitaToolStripMenuItem"
        resources.ApplyResources(Me.DireitaToolStripMenuItem, "DireitaToolStripMenuItem")
        '
        'DireitaInferiorToolStripMenuItem1
        '
        Me.DireitaInferiorToolStripMenuItem1.Name = "DireitaInferiorToolStripMenuItem1"
        resources.ApplyResources(Me.DireitaInferiorToolStripMenuItem1, "DireitaInferiorToolStripMenuItem1")
        '
        'DireitaSuperiorToolStripMenuItem1
        '
        Me.DireitaSuperiorToolStripMenuItem1.Name = "DireitaSuperiorToolStripMenuItem1"
        resources.ApplyResources(Me.DireitaSuperiorToolStripMenuItem1, "DireitaSuperiorToolStripMenuItem1")
        '
        'EsquerdaToolStripMenuItem
        '
        Me.EsquerdaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EsquerdaInferiorToolStripMenuItem2, Me.EsquerdaSuperiorToolStripMenuItem2})
        Me.EsquerdaToolStripMenuItem.Name = "EsquerdaToolStripMenuItem"
        resources.ApplyResources(Me.EsquerdaToolStripMenuItem, "EsquerdaToolStripMenuItem")
        '
        'EsquerdaInferiorToolStripMenuItem2
        '
        Me.EsquerdaInferiorToolStripMenuItem2.Name = "EsquerdaInferiorToolStripMenuItem2"
        resources.ApplyResources(Me.EsquerdaInferiorToolStripMenuItem2, "EsquerdaInferiorToolStripMenuItem2")
        '
        'EsquerdaSuperiorToolStripMenuItem2
        '
        Me.EsquerdaSuperiorToolStripMenuItem2.Name = "EsquerdaSuperiorToolStripMenuItem2"
        resources.ApplyResources(Me.EsquerdaSuperiorToolStripMenuItem2, "EsquerdaSuperiorToolStripMenuItem2")
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        resources.ApplyResources(Me.ToolStripSeparator2, "ToolStripSeparator2")
        '
        'SelecionarTudoToolStripMenuItem
        '
        Me.SelecionarTudoToolStripMenuItem.Name = "SelecionarTudoToolStripMenuItem"
        resources.ApplyResources(Me.SelecionarTudoToolStripMenuItem, "SelecionarTudoToolStripMenuItem")
        '
        'HoraDataToolStripMenuItem
        '
        Me.HoraDataToolStripMenuItem.Name = "HoraDataToolStripMenuItem"
        resources.ApplyResources(Me.HoraDataToolStripMenuItem, "HoraDataToolStripMenuItem")
        '
        'FormatarToolStripMenuItem
        '
        Me.FormatarToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FonteToolStripMenuItem, Me.CorToolStripMenuItem, Me.PlanoDeFundoToolStripMenuItem})
        Me.FormatarToolStripMenuItem.Name = "FormatarToolStripMenuItem"
        resources.ApplyResources(Me.FormatarToolStripMenuItem, "FormatarToolStripMenuItem")
        '
        'FonteToolStripMenuItem
        '
        Me.FonteToolStripMenuItem.Name = "FonteToolStripMenuItem"
        resources.ApplyResources(Me.FonteToolStripMenuItem, "FonteToolStripMenuItem")
        '
        'CorToolStripMenuItem
        '
        Me.CorToolStripMenuItem.Name = "CorToolStripMenuItem"
        resources.ApplyResources(Me.CorToolStripMenuItem, "CorToolStripMenuItem")
        '
        'PlanoDeFundoToolStripMenuItem
        '
        Me.PlanoDeFundoToolStripMenuItem.Name = "PlanoDeFundoToolStripMenuItem"
        resources.ApplyResources(Me.PlanoDeFundoToolStripMenuItem, "PlanoDeFundoToolStripMenuItem")
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SelecionarIdiomaToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        resources.ApplyResources(Me.ToolStripMenuItem1, "ToolStripMenuItem1")
        '
        'SelecionarIdiomaToolStripMenuItem
        '
        Me.SelecionarIdiomaToolStripMenuItem.Name = "SelecionarIdiomaToolStripMenuItem"
        resources.ApplyResources(Me.SelecionarIdiomaToolStripMenuItem, "SelecionarIdiomaToolStripMenuItem")
        '
        'SobreToolStripMenuItem
        '
        Me.SobreToolStripMenuItem.Name = "SobreToolStripMenuItem"
        resources.ApplyResources(Me.SobreToolStripMenuItem, "SobreToolStripMenuItem")
        '
        'frmMain
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        resources.ApplyResources(Me, "$this")
        Me.Controls.Add(Me.txtEditor)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMain"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private Sub AbrirToolStripMenuItem_Disposed(sender As Object, e As EventArgs) Handles AbrirToolStripMenuItem.Disposed

    End Sub

    Friend WithEvents txtEditor As System.Windows.Forms.TextBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ArquivoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NovoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AbrirToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalvarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SairToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecoortarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopiarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ColarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeletarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SelecionarTudoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HoraDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FormatarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FonteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PlanoDeFundoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents PosiçãaoDaLegendaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CentroMeioToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CentroInferiorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CentroSuperiorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DireitaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DireitaInferiorToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DireitaSuperiorToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EsquerdaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EsquerdaInferiorToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EsquerdaSuperiorToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SobreToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents SelecionarIdiomaToolStripMenuItem As ToolStripMenuItem
End Class
